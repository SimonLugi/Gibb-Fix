#ifndef APT_PRIVATE_UNMET_H
#define APT_PRIVATE_UNMET_H

#include <apt-pkg/macros.h>

class CommandLine;

APT_PUBLIC bool UnMet(CommandLine &CmdL);

#endif

#ifndef APT_PRIVATE_MOO_H
#define APT_PRIVATE_MOO_H

#include <apt-pkg/macros.h>

class CommandLine;

APT_PUBLIC bool DoMoo(CommandLine &CmdL);

#endif
